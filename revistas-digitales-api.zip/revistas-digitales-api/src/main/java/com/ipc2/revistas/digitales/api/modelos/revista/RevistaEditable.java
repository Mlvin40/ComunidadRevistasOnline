/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ipc2.revistas.digitales.api.modelos.revista;


/**
 *
 * @author melvin
 */
public class RevistaEditable {
    
//    private String nombre;
//    //la descripcion de la revista es el contenido de la revista
//    private String descripcion;
//    private String categoria;
//    private String autor;
//    private boolean estadoComentar;
//    private boolean estadoMeGusta;
//    private boolean estadoSuscribirse;
    
    
    
}
