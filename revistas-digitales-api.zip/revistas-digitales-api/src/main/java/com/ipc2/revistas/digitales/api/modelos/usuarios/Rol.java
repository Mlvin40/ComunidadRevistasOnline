package com.ipc2.revistas.digitales.api.modelos.usuarios;

public enum Rol {
    ADMINISTRADOR,
    EDITOR,
    SUSCRIPTOR,
    ANUNCIANTE

}
